package org.test.project1.domain;

public class ImageVo {

	private int imageSeq;
	private String imagePath;
	
	public int getImageSeq() {
		return imageSeq;
	}
	public void setImageSeq(int imageSeq) {
		this.imageSeq = imageSeq;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	
}
