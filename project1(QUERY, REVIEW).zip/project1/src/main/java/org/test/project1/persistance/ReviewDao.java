package org.test.project1.persistance;

import java.util.List;

import org.test.project1.domain.ReviewVo;

public interface ReviewDao {
	
	public List<ReviewVo> reviewSelectAll();
	public ReviewVo reviewSelectOne(int seq);
	public void reviewInsert(ReviewVo reviewVo);
	public void reviewUpdate(ReviewVo reviewVo);
	public void reviewDelete(int seq);
}
