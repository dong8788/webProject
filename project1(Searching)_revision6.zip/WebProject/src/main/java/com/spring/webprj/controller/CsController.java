package com.spring.webprj.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.webprj.common.Criteria;
import com.spring.webprj.common.PageMaker;
import com.spring.webprj.common.SearchCriteria;
import com.spring.webprj.common.SearchVO;
import com.spring.webprj.domain.CenQueryVo;
import com.spring.webprj.domain.CustomerVo;
import com.spring.webprj.service.CartService;
import com.spring.webprj.service.CenQueryService;
import com.spring.webprj.service.FaqService;
import com.spring.webprj.service.NoticeService;

@Controller
@RequestMapping("/cs")
public class CsController {
	
	@Autowired
	private NoticeService noticeservice;
	
	@Autowired
	private CenQueryService cenQueryservice;
	
	@Autowired
	private FaqService faqservice;
	
	@Autowired
	private CartService cartservice;
	
	@GetMapping("/test")
	public void testCenInsert() {
		
		for(int i=2; i<=399; i++ ) {
			CenQueryVo cqv = new CenQueryVo();
			cqv.setCenQuerySeq(1);
			cqv.setContent("내용" + i);
			cqv.setCusSeq(i);
			cqv.setOpen("공개");
			cqv.setQueryType("샘플타입");
			cqv.setReply("샘플답변");
			cqv.setSellerSeq(i);
			cqv.setTitle("샘플제목" + i);
			System.out.println(cqv);
			cenQueryservice.insert(cqv);
		}
		
	}
	
	@GetMapping("/cenquery")
	public String cenquery(@ModelAttribute("scri") SearchCriteria scri, 
			HttpSession session, 
			Model model) throws Exception {
		
		if(session.getAttribute("seller1") == null && session.getAttribute("login") != null) {
				int cartSize = cartservice.select(((CustomerVo)session.getAttribute("login")).getCusSeq()).size();
				model.addAttribute("cartSize", cartSize);
		}
		System.out.println(scri);
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(scri);
		
		pageMaker.setTotalCount(cenQueryservice.listCount(scri));
		
		model.addAttribute("pageMaker", pageMaker);
		model.addAttribute("userCenQueryList", cenQueryservice.list(scri));
		
		System.out.println("page: " + scri.getPage());
		System.out.println(cenQueryservice.list(scri) + "\n");
		System.out.println(pageMaker+"\n");
		System.out.println("searchType: " + scri.getSearchType());
		System.out.println("keyword: " + scri.getKeyword());
		
		return "cs/cenquery";
	}

	
	@GetMapping("/faq")
	public String faq(Model model, HttpSession session, SearchVO search) {
		if(session.getAttribute("seller1") == null && session.getAttribute("login") != null) {
			int cartSize = cartservice.select(((CustomerVo)session.getAttribute("login")).getCusSeq()).size();
			model.addAttribute("cartSize", cartSize);
		}
		PageMaker pm = new PageMaker();
		pm.setCri(search);
		System.out.println(search.getRowStart());
		System.out.println("parameter(페이지번호) : "+search.getPage());
		System.out.println("검색 조건 : "+ search.getCondition());
		System.out.println("검색어 : "+ search.getKeyword());
		System.out.println("rowStart : "+ search.getRowStart());
		System.out.println("rowEnd : "+ search.getRowEnd());
		pm.setTotalCount(faqservice.listCount(search));
		model.addAttribute("faqList", faqservice.selectAll(search));
		model.addAttribute("pageMaker", pm);
		return "cs/faq";
	}
	
	@GetMapping("/notice")
	public String notice(Model model, HttpSession session, SearchVO search) {
		if(session.getAttribute("seller1") == null && session.getAttribute("login") != null) {
			int cartSize = cartservice.select(((CustomerVo)session.getAttribute("login")).getCusSeq()).size();
			model.addAttribute("cartSize", cartSize);
		}
		PageMaker pm = new PageMaker();
		pm.setCri(search);
		System.out.println(search.getRowStart());
		System.out.println("parameter(페이지번호) : "+search.getPage());
		System.out.println("검색 조건 : "+ search.getCondition());
		System.out.println("검색어 : "+ search.getKeyword());
		System.out.println("rowStart : "+ search.getRowStart());
		System.out.println("rowEnd : "+ search.getRowEnd());
		pm.setTotalCount(noticeservice.listCount(search));
		model.addAttribute("noticeList", noticeservice.selectAll(search));
		model.addAttribute("pageMaker", pm);
		return "cs/notice";
	}
	
	@GetMapping("/main")
	public String main(HttpSession session, Model model){
		if(session.getAttribute("seller1") == null && session.getAttribute("login") != null) {
			int cartSize = cartservice.select(((CustomerVo)session.getAttribute("login")).getCusSeq()).size();
			model.addAttribute("cartSize", cartSize);
		}
		return "cs/support";
	}

}
