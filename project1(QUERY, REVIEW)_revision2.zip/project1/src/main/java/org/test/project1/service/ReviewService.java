package org.test.project1.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.test.project1.domain.ReviewVo;

public interface ReviewService {

	public List<ReviewVo> reviewSelectAll();
	public ReviewVo reviewSelectOne(int seq);
	public void reviewInsert(ReviewVo reviewVo);
	public void reviewUpdate(ReviewVo reviewVo);
	public void reviewDelete(int seq);
}
