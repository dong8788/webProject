package com.spring.shop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.shop.domain.FaqVo;
import com.spring.shop.service.FaqService;

@Controller
public class FaqController {
	
	@Autowired
	private FaqService faqService;
	
	@RequestMapping(value="/faq/list")
	public String list(Model model) {
		List<FaqVo> faqList = faqService.faqList();
		model.addAttribute("faqList", faqList);
		return "/faq/list";
	}
	
	@RequestMapping(value="/faq/view/{seq}")
	public String view(Model model, @PathVariable int seq) {
		FaqVo faqVo = faqService.faqView(seq);
		model.addAttribute("faqVo", faqVo);
		return "/faq/view";
	}
	
	@RequestMapping(value="/faq/insert", method=RequestMethod.GET)
	public String insert(Model model) {
		model.addAttribute("faqVo", new FaqVo());
		return "/faq/insert";
	}
	
	@RequestMapping(value="/faq/insert", method=RequestMethod.POST)
	public String insert(FaqVo faqVo) {
		boolean result = faqService.faqInsert(faqVo);
		return (result) ? "redirect:/faq/list" : "redirect:/faq/insert";
	}
	
	@RequestMapping(value="/faq/delete/{seq}")
	public String delete(Model model, @PathVariable int seq) {
		boolean result = faqService.faqDelete(seq);
		return (!result) ? "redirect:/faq/list" : "faq/delete";
	}
	
	@RequestMapping(value="/faq/update/{seq}", method=RequestMethod.GET)
	public String update(Model model, @PathVariable int seq) {
		FaqVo faqVo = faqService.faqView(seq);
		model.addAttribute("faqVo", faqVo);
		return "/faq/update";
	}
	
	@RequestMapping(value="/faq/update/{seq}", method=RequestMethod.POST)
	public String update(FaqVo faqVo, @PathVariable int seq) {
		System.out.println("updated faqVo : " + faqVo);
		boolean result = faqService.faqUpdate(faqVo);
		return (!result) ? "redirect:/faq/update/"+seq : "redirect:/faq/list";
	}
}
