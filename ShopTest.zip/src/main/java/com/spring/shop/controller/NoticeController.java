package com.spring.shop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.shop.domain.NoticeVo;
import com.spring.shop.service.NoticeService;

@Controller
public class NoticeController {
	
	@Autowired
	private NoticeService noticeService;
	
	@RequestMapping(value="/notice/list")
	public String list(Model model) {
		List<NoticeVo> noticeVo = noticeService.noticeList();
		model.addAttribute("noticeList", noticeVo);
		return "/notice/list";
	}
	
	@RequestMapping(value="/notice/view/{seq}")
	public String read(Model model, @PathVariable int seq) {
		NoticeVo noticeVo = noticeService.noticeView(seq);
		System.out.println("noticeVo : " + noticeVo);
		model.addAttribute("noticeVo", noticeVo);
		return "/notice/view";
	}
	
	@RequestMapping(value="/notice/insert", method=RequestMethod.GET)
	public String insert(Model model) {
		model.addAttribute("noticeVo", new NoticeVo());
		return "/notice/insert";
	}
	
	@RequestMapping(value="/notice/insert", method=RequestMethod.POST)
	public String insert(NoticeVo noticeVo) {
		boolean result = noticeService.noticeInsert(noticeVo);
		return (result) ? "redirect:/notice/list" : "redirect:/notice/insert";
	}
	
	@RequestMapping(value="/notice/delete/{seq}")
	public String delete(Model model, @PathVariable int seq) {
		boolean result = noticeService.noticeDelete(seq);
		return (!result) ? "redirect:/notice/list" : "notice/delete";
	}
	
	@RequestMapping(value="/notice/update/{seq}", method=RequestMethod.GET)
	public String update(Model model, @PathVariable int seq) {
		NoticeVo noticeVo = noticeService.noticeView(seq);
		model.addAttribute("noticeVo", noticeVo);
		return "/notice/update";
	}
	
	@RequestMapping(value="/notice/update/{seq}", method=RequestMethod.POST)
	public String update(NoticeVo noticeVo, @PathVariable int seq) {
		System.out.println("updated noticeVo : " + noticeVo);
		boolean result = noticeService.noticeUpdate(noticeVo);
		return (!result) ? "redirect:/notice/update/"+seq : "redirect:/notice/list";
	}
}
