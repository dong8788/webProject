package com.spring.shop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.shop.domain.CartVo;
import com.spring.shop.service.CartService;

@Controller
public class CartController {

	@Autowired
	private CartService cartService;
	
	@RequestMapping(value="/cart/list")
	public String list(Model model) {
		List<CartVo> cartList = cartService.cartList();
		model.addAttribute("cartList", cartList);
		return "/cart/list";
	}
	
	@RequestMapping(value="/cart/view/{seq}")
	public String view(Model model, @PathVariable int seq) {
		CartVo cartVo = cartService.cartView(seq);
		model.addAttribute("cartVo", cartVo);
		return "/cart/view";
	}
	
	@RequestMapping(value="/cart/insert", method=RequestMethod.GET)
	public String insert(Model model) {
		model.addAttribute("cartVo", new CartVo());
		return "/cart/insert";
	}
	
	@RequestMapping(value="/cart/insert", method=RequestMethod.POST)
	public String insert(CartVo cartVo) {
		boolean result = cartService.cartInsert(cartVo);
		return (result) ? "redirect:/cart/list" : "redirect:/cart/insert";
	}
	
	@RequestMapping(value="/cart/delete/{seq}")
	public String delete(Model model, @PathVariable int seq) {
		boolean result = cartService.cartDelete(seq);
		return (!result) ? "redirect:/cart/list" : "cart/delete";
	}
	
	@RequestMapping(value="/cart/update/{seq}", method=RequestMethod.GET)
	public String update(Model model, @PathVariable int seq) {
		CartVo cartVo = cartService.cartView(seq);
		model.addAttribute("cartVo", cartVo);
		return "/cart/update";
	}
	
	@RequestMapping(value="/cart/update/{seq}", method=RequestMethod.POST)
	public String update(CartVo cartVo, @PathVariable int seq) {
		System.out.println("updated cartVo : " + cartVo);
		boolean result = cartService.cartUpdate(cartVo);
		return (!result) ? "redirect:/cart/update/"+seq : "redirect:/cart/list";
	}
}
