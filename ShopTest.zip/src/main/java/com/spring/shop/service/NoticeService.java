package com.spring.shop.service;

import java.util.List;

import com.spring.shop.domain.NoticeVo;

public interface NoticeService {
	public List<NoticeVo> noticeList();
	public NoticeVo noticeView(int seq);
	public boolean noticeInsert(NoticeVo noticeVo);
	public boolean noticeDelete(int seq);
	public boolean noticeUpdate(NoticeVo noticeVo);
}
