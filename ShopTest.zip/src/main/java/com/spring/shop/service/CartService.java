package com.spring.shop.service;

import java.util.List;

import com.spring.shop.domain.CartVo;

public interface CartService {
	public List<CartVo> cartList();
	public CartVo cartView(int seq);
	public boolean cartInsert(CartVo cartVo);
	public boolean cartDelete(int seq);
	public boolean cartUpdate(CartVo cartVo);
}
