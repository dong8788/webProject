package com.spring.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.shop.domain.CartVo;
import com.spring.shop.persistence.CartDao;

@Service
public class CartServiceImpl implements CartService{

	@Autowired
	private CartDao cartDao;
	
	@Override
	public List<CartVo> cartList() {
		return cartDao.list();
	}

	@Override
	public CartVo cartView(int seq) {
		return cartDao.read(seq);
	}

	@Override
	public boolean cartInsert(CartVo cartVo) {
		return cartDao.insert(cartVo);
	}

	@Override
	public boolean cartDelete(int seq) {
		return cartDao.delete(seq);
	}

	@Override
	public boolean cartUpdate(CartVo cartVo) {
		return cartDao.update(cartVo);
	}

}
