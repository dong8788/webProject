package com.spring.shop.domain;

import java.sql.Timestamp;

public class NoticeVo {
	private int noticeSeq;
	private String noticeCategory;
	private String content;
	private String title;
	private Timestamp regDate;
	
	public int getNoticeSeq() {
		return noticeSeq;
	}
	public void setNoticeSeq(int noticeSeq) {
		this.noticeSeq = noticeSeq;
	}
	public String getNoticeCategory() {
		return noticeCategory;
	}
	public void setNoticeCategory(String noticeCategory) {
		this.noticeCategory = noticeCategory;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Timestamp getRegDate() {
		return regDate;
	}
	public void setRegDate(Timestamp regDate) {
		this.regDate = regDate;
	}
	
	@Override
	public String toString() {
		return "NoticeVo [noticeSeq=" + noticeSeq + ", noticeCategory=" + noticeCategory + ", content=" + content
				+ ", title=" + title + ", regDate=" + regDate + "]";
	}
}
