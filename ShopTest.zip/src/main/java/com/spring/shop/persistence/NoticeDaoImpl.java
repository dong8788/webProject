package com.spring.shop.persistence;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.shop.domain.NoticeVo;

@Repository
public class NoticeDaoImpl implements NoticeDao{

	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;
	
	@Override
	public List<NoticeVo> list() {
		return sqlSessionTemplate.selectList("noticeDao.selectAll");
	}

	@Override
	public NoticeVo read(int noticeSeq) {
		return sqlSessionTemplate.selectOne("noticeDao.select", noticeSeq);
	}

	@Override
	public boolean insert(NoticeVo noticeVo) {
		int n = sqlSessionTemplate.insert("noticeDao.insert", noticeVo);
		return (n == 0) ? false : true;
	}

	@Override
	public boolean delete(int noticeSeq) {
		int n = sqlSessionTemplate.delete("noticeDao.delete", noticeSeq);
		return (n == 0) ? false : true;
	}

	@Override
	public boolean update(NoticeVo noticeVo) {
		System.out.println("noticeVo : " + noticeVo);
		int n = sqlSessionTemplate.update("noticeDao.update", noticeVo);
		return (n == 0) ? false : true;
	}
}
