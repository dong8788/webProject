package com.spring.shop.persistence;

import java.util.List;

import com.spring.shop.domain.NoticeVo;

public interface NoticeDao {

	public List<NoticeVo> list();
	public NoticeVo read(int noticeSeq);
	public boolean insert(NoticeVo noticeVo);
	public boolean delete(int noticeSeq);
	public boolean update(NoticeVo noticeVo);
}
