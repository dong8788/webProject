package com.spring.shop.persistence;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.shop.domain.CartVo;

@Repository
public class CartDaoImpl implements CartDao{

	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	@Override
	public List<CartVo> list() {
		return sqlSessionTemplate.selectList("cartDao.selectAll");
	}

	@Override
	public CartVo read(int seq) {
		return sqlSessionTemplate.selectOne("cartDao.select", seq);
	}

	@Override
	public boolean insert(CartVo cartVo) {
		int n = sqlSessionTemplate.insert("cartDao.insert", cartVo);
		return (n == 0) ? false : true;
	}

	@Override
	public boolean delete(int seq) {
		int n = sqlSessionTemplate.delete("cartDao.insert", seq);
		return (n == 0) ? false : true;
	}

	@Override
	public boolean update(CartVo cartVo) {
		int n = sqlSessionTemplate.update("cartDao.insert", cartVo);
		return (n == 0) ? false : true;
	}
	
}
