package com.spring.shop.persistence;

import java.util.List;

import com.spring.shop.domain.CartVo;

public interface CartDao {
	public List<CartVo> list();
	public CartVo read(int seq);
	public boolean insert(CartVo cartVo);
	public boolean delete(int seq);
	public boolean update(CartVo cartVo);
}
