package com.spring.webprj.domain;

import java.util.List;

public class MultiRowPoVo {
	private List<PoVo> poVos;

	public List<PoVo> getPoVos() {
		return poVos;
	}

	public void setPoVos(List<PoVo> poVos) {
		this.poVos = poVos;
	}
	
	
	
}
