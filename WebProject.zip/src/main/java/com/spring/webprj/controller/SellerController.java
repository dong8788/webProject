package com.spring.webprj.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.webprj.domain.ProductVo;
import com.spring.webprj.domain.SellerVo;
import com.spring.webprj.service.ProductService;
import com.spring.webprj.service.SellerService;

@Controller
@RequestMapping("/seller")
public class SellerController {
	
	@Autowired
	private ProductService prodservice;
	
	@Autowired
	private SellerService sellerservice;

	@GetMapping("/prodWrite")
	public void prodWrite() {
		System.out.println("get : prodwrite");
	}
	
	@GetMapping("/prodList")
	public void prodList(Model model, HttpSession session) {
		List<ProductVo> prodList = prodservice.list(sellerservice.select(((SellerVo)session.getAttribute("login")).getId()).getSellerSeq());
		System.out.println("get : prodList");
		System.out.println(prodList);
		model.addAttribute("prodList", prodList);
	}
	
	@GetMapping("/prodModify/{prodSeq}")
	public String prodModify(@PathVariable int prodSeq,Model model) {
		model.addAttribute("prod", prodservice.getProd(prodSeq));
		return "/seller/prodModify";
	}
}
