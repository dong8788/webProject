package com.spring.webprj.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.webprj.service.FaqService;
import com.spring.webprj.service.NoticeService;

@Controller
@RequestMapping("/cs")
public class CsController {
	
	@Autowired
	private NoticeService noticeservice;
	
	@Autowired
	private FaqService faqservice;
	
	@GetMapping("/cenquery")
	public String cenquery() {
		return "cs/cenquery";
	}
	
	@GetMapping("/faq")
	public String faq(Model model) {
		model.addAttribute("faqList", faqservice.selectAll());
		return "cs/faq";
	}
	
	@GetMapping("/notice")
	public String notice(Model model) {
		System.out.println("get : notice");
		model.addAttribute("noticeList", noticeservice.selectAll());
		System.out.println(noticeservice.selectAll());
		return "cs/notice";
	}
	
	@GetMapping("/main")
	public String main(){
		return "cs/support";
	}

}
