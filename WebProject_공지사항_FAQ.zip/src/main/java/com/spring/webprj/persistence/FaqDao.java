package com.spring.webprj.persistence;

import java.util.List;

import com.spring.webprj.domain.FaqVo;

public interface FaqDao {
	public List<FaqVo> list();
	public FaqVo read(int seq);
	public boolean insert(FaqVo faqVo);
	public boolean delete(int seq);
	public boolean update(FaqVo faqVo);
}
