package com.spring.webprj.service;

import java.util.List;

import com.spring.webprj.domain.FaqVo;

public interface FaqService {
	public List<FaqVo> faqList();
	public FaqVo faqView(int seq);
	public boolean faqInsert(FaqVo faqVo);
	public boolean faqDelete(int seq);
	public boolean faqUpdate(FaqVo faqVo);
}
