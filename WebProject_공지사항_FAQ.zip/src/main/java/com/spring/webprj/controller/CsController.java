package com.spring.webprj.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.webprj.domain.FaqVo;
import com.spring.webprj.service.FaqService;
import com.spring.webprj.domain.NoticeVo;
import com.spring.webprj.service.NoticeService;

@Controller
@RequestMapping("/cs")
public class CsController {
	
	@Autowired
	private NoticeService noticeService;
	@Autowired
	private FaqService faqService;
	
	//고객센터 메인
	@GetMapping("/main")
	public String main(){
		return "cs/support";
	}
	
	//문의사항
	@GetMapping("/cenquery")
	public String cenquery() {
		return "cs/cenquery";
	}
	
	//FAQ
	@GetMapping("/faq")
	public String faqList(Model model) {
		List<FaqVo> faqList = faqService.faqList();
		model.addAttribute("faqList", faqList);
		return "cs/faq/list";
	}
	@GetMapping("/faq/view/{seq}")
	public String faqView(Model model, @PathVariable int seq) {
		FaqVo faqVo = faqService.faqView(seq);
		model.addAttribute("faqVo", faqVo);
		return "cs/faq/view";
	}
	@GetMapping("/faq/insert")
	public String faqInsert(Model model) {
		model.addAttribute("faqVo", new FaqVo());
		return "cs/faq/insert";
	}
	@PostMapping("/faq/insert")
	public String faqInsert(FaqVo faqVo) {
		boolean result = faqService.faqInsert(faqVo);
		return (result) ? "redirect:/cs/faq" : "redirect:/cs/faq/insert";
	}
	@GetMapping("/faq/delete/{seq}")
	public String faqDelete(Model model, @PathVariable int seq) {
		boolean result = faqService.faqDelete(seq);
		return (!result) ? "redirect:cs/faq" : "cs/faq/delete";
	}
	@GetMapping("/faq/update/{seq}")
	public String faqUpdate(Model model, @PathVariable int seq) {
		FaqVo faqVo = faqService.faqView(seq);
		model.addAttribute("faqVo", faqVo);
		return "cs/faq/update";
	}
	@PostMapping("/faq/update/{seq}")
	public String faqUpdate(FaqVo faqVo, @PathVariable int seq) {
		System.out.println("updated faqVo : " + faqVo);
		boolean result = faqService.faqUpdate(faqVo);
		return (!result) ? "redirect:/cs/faq/update/"+seq : "redirect:/cs/faq";
	}
	//FAQ 끝
	
	//공지사항
	@GetMapping("/notice")
	public String noticeList(Model model) {
		List<NoticeVo> noticeVo = noticeService.noticeList();
		model.addAttribute("noticeList", noticeVo);
		return "cs/notice/list";
	}
	@GetMapping("/notice/view/{seq}")
	public String noticeView(Model model, @PathVariable int seq) {
		NoticeVo noticeVo = noticeService.noticeView(seq);
		System.out.println("noticeVo : " + noticeVo);
		model.addAttribute("noticeVo", noticeVo);
		return "cs/notice/view";
	}
	@GetMapping("/notice/insert")
	public String noticeInsert(Model model) {
		model.addAttribute("noticeVo", new NoticeVo());
		return "cs/notice/insert";
	}
	@PostMapping("/notice/insert")
	public String noticeInsert(NoticeVo noticeVo) {
		boolean result = noticeService.noticeInsert(noticeVo);
		return (result) ? "redirect:/cs/notice" : "redirect:/cs/notice/insert";
	}
	@GetMapping("/notice/delete/{seq}")
	public String noticeDelete(Model model, @PathVariable int seq) {
		boolean result = noticeService.noticeDelete(seq);
		return (!result) ? "redirect:/cs/notice" : "cs/notice/delete";
	}
	@GetMapping("/notice/update/{seq}")
	public String noticeUpdate(Model model, @PathVariable int seq) {
		NoticeVo noticeVo = noticeService.noticeView(seq);
		model.addAttribute("noticeVo", noticeVo);
		return "cs/notice/update";
	}
	@PostMapping("/notice/update/{seq}")
	public String noticeUpdate(NoticeVo noticeVo, @PathVariable int seq) {
		System.out.println("updated noticeVo : " + noticeVo);
		boolean result = noticeService.noticeUpdate(noticeVo);
		return (!result) ? "redirect:/cs/notice/update/"+seq : "redirect:/cs/notice";
	}
	//공지사항 끝
}
