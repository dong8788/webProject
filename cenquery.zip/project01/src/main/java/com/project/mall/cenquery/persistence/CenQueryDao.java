package com.project.mall.cenquery.persistence;

import java.util.List;

import com.project.mall.cenquery.domain.CenQueryVo;

public interface CenQueryDao {
	
	public List<CenQueryVo> list();  //전체목록보기
	public CenQueryVo read(int req);  //하나보기
	public boolean insert(CenQueryVo dto);  //입력
	public boolean update(CenQueryVo dto);  //수정
	public boolean delete(CenQueryVo dto);  //삭제

}
