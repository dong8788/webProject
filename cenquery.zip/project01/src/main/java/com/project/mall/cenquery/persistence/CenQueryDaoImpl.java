package com.project.mall.cenquery.persistence;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.mall.cenquery.domain.CenQueryVo;

@Repository
public class CenQueryDaoImpl implements CenQueryDao {
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	@Override
	public List<CenQueryVo> list() {
		return sqlSessionTemplate.selectList("CenQueryDao.list");
	}

	@Override
	public CenQueryVo read(int seq) {
		return sqlSessionTemplate.selectOne("CenQueryDao.read",seq);
	}

	@Override
	public boolean insert(CenQueryVo dto) {
		System.out.println("insert dto : " + dto);
		int n = sqlSessionTemplate.insert("CenQueryDao.insert", dto);
		System.out.println("n : " + n);
		return (n == 0) ? false : true;
	}

	@Override
	public boolean update(CenQueryVo dto) {
		System.out.println("update dto : " + dto);
		int n = sqlSessionTemplate.update("CenQueryDao.update", dto);
		return (n == 0) ? false : true;
	}

	@Override
	public boolean delete(CenQueryVo dto) {
		int n = sqlSessionTemplate.delete("CenQueryDao.delete", dto);
		if(n != 1) {
			return false;
		} else {
			return true;	
		}
	}
	


}
