package com.project.mall.cenquery.service;

import java.util.List;

import com.project.mall.cenquery.domain.CenQueryVo;

public interface CenQueryService {
	
	public List<CenQueryVo> cenQueryList();
	public CenQueryVo CenQueryRead(int seq);
	public boolean CenQueryInsert(CenQueryVo dto);
	public boolean CenQueryUpdate(CenQueryVo dto);
	public boolean CenQueryDelete(int seq);

}
