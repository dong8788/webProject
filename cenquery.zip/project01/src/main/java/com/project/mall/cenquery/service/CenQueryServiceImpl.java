package com.project.mall.cenquery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.mall.cenquery.domain.CenQueryVo;
import com.project.mall.cenquery.persistence.CenQueryDao;

@Service
public class CenQueryServiceImpl implements CenQueryService {
	
	@Autowired
	private CenQueryDao cenQueryDao;

	@Override
	public List<CenQueryVo> cenQueryList() {
		// TODO Auto-generated method stub
		return cenQueryDao.list();
	}

	@Override
	public CenQueryVo CenQueryRead(int seq) {
		// TODO Auto-generated method stub
		return cenQueryDao.read(seq);
	}

	@Override
	public boolean CenQueryInsert(CenQueryVo dto) {
		return cenQueryDao.insert(dto);
	}

	@Override
	public boolean CenQueryUpdate(CenQueryVo dto) {
		return cenQueryDao.update(dto);
	}

	@Override
	public boolean CenQueryDelete(int seq) {
		CenQueryVo dto = cenQueryDao.read(seq);
		return cenQueryDao.delete(dto);
	}




	

}
