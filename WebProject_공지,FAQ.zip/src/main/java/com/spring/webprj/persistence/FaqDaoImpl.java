package com.spring.webprj.persistence;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.webprj.domain.FaqVo;

@Repository
public class FaqDaoImpl implements FaqDao{

	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	@Override
	public List<FaqVo> list() {
		return sqlSessionTemplate.selectList("faqDao.selectAll");
	}

	@Override
	public FaqVo read(int seq) {
		return sqlSessionTemplate.selectOne("faqDao.select", seq);
	}

	@Override
	public boolean insert(FaqVo faqVo) {
		int n = sqlSessionTemplate.insert("faqDao.insert", faqVo);
		return (n == 0) ? false : true;
	}

	@Override
	public boolean delete(int seq) {
		int n = sqlSessionTemplate.delete("faqDao.delete", seq);
		return (n == 0) ? false : true;
	}

	@Override
	public boolean update(FaqVo faqVo) {
		int n = sqlSessionTemplate.update("faqDao.update", faqVo);
		return (n == 0) ? false : true;
	}

}
