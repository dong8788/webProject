package com.spring.webprj.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.webprj.domain.FaqVo;
import com.spring.webprj.persistence.FaqDaoImpl;

@Service
public class FaqServiceImpl implements FaqService{
	
	@Autowired
	private FaqDaoImpl faqDao;

	@Override
	public List<FaqVo> faqList() {
		return faqDao.list();
	}

	@Override
	public FaqVo faqView(int seq) {
		return faqDao.read(seq);
	}

	@Override
	public boolean faqInsert(FaqVo faqVo) {
		return faqDao.insert(faqVo);
	}

	@Override
	public boolean faqDelete(int seq) {
		return faqDao.delete(seq);
	}

	@Override
	public boolean faqUpdate(FaqVo faqVo) {
		return faqDao.update(faqVo);
	}
	
}
