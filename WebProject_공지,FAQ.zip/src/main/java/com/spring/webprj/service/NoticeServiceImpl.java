package com.spring.webprj.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.webprj.domain.NoticeVo;
import com.spring.webprj.persistence.NoticeDao;

@Service
public class NoticeServiceImpl implements NoticeService{
	
	@Autowired
	private NoticeDao noticeDao;

	@Override
	public List<NoticeVo> noticeList() {
		return noticeDao.list();
	}

	@Override
	public NoticeVo noticeView(int seq) {
		return noticeDao.read(seq);
	}

	@Override
	public boolean noticeInsert(NoticeVo noticeVo) {
		return noticeDao.insert(noticeVo);
	}

	@Override
	public boolean noticeDelete(int seq) {
		return noticeDao.delete(seq);
	}

	@Override
	public boolean noticeUpdate(NoticeVo noticeVo) {
		return noticeDao.update(noticeVo);
	}

}
