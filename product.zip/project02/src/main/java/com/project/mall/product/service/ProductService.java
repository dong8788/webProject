package com.project.mall.product.service;

import java.util.List;

import com.project.mall.product.domain.ProductVo;

public interface ProductService {
	
	public List<ProductVo> productList();
	public ProductVo ProductRead(int seq);
	public void ProductInsert(ProductVo dto);
	public boolean ProductUpdate(ProductVo dto);
	public boolean ProductDelete(int seq);

}
