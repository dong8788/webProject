package com.project.mall.product.persistence;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.mall.product.domain.ProductVo;

@Repository
public class ProductDaoImpl implements ProductDao {
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	@Override
	public List<ProductVo> list() {
		return sqlSessionTemplate.selectList("ProductDao.list");
	}

	@Override
	public ProductVo read(int seq) {
		return sqlSessionTemplate.selectOne("ProductDao.read",seq);
	}

	@Override
	public void insert(ProductVo dto) {
		sqlSessionTemplate.insert("ProductDao.insert", dto);
	}

	@Override
	public boolean update(ProductVo dto) {
		System.out.println("update dto : " + dto);
		int n = sqlSessionTemplate.update("ProductDao.update", dto);
		return (n == 0) ? false : true;
	}

	@Override
	public boolean delete(ProductVo dto) {
		int n = sqlSessionTemplate.delete("ProductDao.delete", dto);
		if(n != 1) {
			return false;
		} else {
			return true;	
		}
	}


}
