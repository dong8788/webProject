package com.project.mall.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.project.mall.product.domain.ProductVo;
import com.project.mall.product.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	private ProductService productService;
	
//	@Resource(name="uploadPath")
//	private String uploadPath;
//	
	
	//전체조회
	@RequestMapping(value="/product/list")
	public String list(Model model) {
		List<ProductVo> productVo = productService.productList();
		model.addAttribute("productList", productVo);
		return "/product/list";
	}
	
	
	//상세조회
	@RequestMapping(value="/product/read/{productSeq}")
	public ModelAndView read(ModelAndView mav, @PathVariable int productSeq) {
		ProductVo productVo = productService.ProductRead(productSeq);
		mav.addObject("productVo", productVo);
		mav.setViewName("/product/read");
		return mav;
	}
	
	//게시글 작성페이지 이동
	@GetMapping(value="/product/insert")
	public String insert(Model model) {
		model.addAttribute("dto", new ProductVo());
		return "/product/insert";
	}
	
	//DB 등록 요청
//	@PostMapping(value="/product/insert")
//	public String insert(ProductVo dto, MultipartFile file) throws Exception {
//		String imgUploadPath = uploadPath + File.separator + "imgUpload";
//		String ymdPath = UploadFileUtils.calcPath(imgUploadPath);
//		String fileName = null;
//		
//		if(file != null) {
//			fileName =  UploadFileUtils.fileUpload(imgUploadPath, file.getOriginalFilename(), file.getBytes(), ymdPath); 
//		} else {
//			fileName = uploadPath + File.separator + "images" + File.separator + "none.png";
//		}
//		
//		dto.setPhotoUrl(File.separator + "imgUpload" + ymdPath + File.separator + fileName);
//		dto.setThumbUrl(File.separator + "imgUpload" + ymdPath + File.separator + "s" + File.separator + "s_" + fileName);
//		
//		productService.ProductInsert(dto);
//		return "redirect:/product/list";
//		
//	}
//	
	
	//게시물 수정페이지
	@GetMapping(value="/product/update/{productSeq}")
	public String update(Model model, @PathVariable int productSeq) {
		ProductVo productVo = productService.ProductRead(productSeq);
		model.addAttribute("dto", productVo);
		return "/product/update";	
	}
	
	//게시물 수정
	@PostMapping(value="/product/update/{productSeq}")
	public String update(ProductVo dto, @PathVariable int productSeq) {
		boolean result = productService.ProductUpdate(dto);
		if(!result) {
			return "redirect:/product/update/"+productSeq;
		}
		return "redirect:/product/list/";
	}
	
	//삭제
	@GetMapping(value="/product/delete/{productSeq}")
	public String delete(Model model, @PathVariable int productSeq) {
		model.addAttribute("productSeq", productSeq);
		return "/product/delete";
	}
	
	//삭제페이지
	@PostMapping(value="/product/delete/{productSeq}")
	public String delete(@PathVariable int productSeq) {
		boolean result = productService.ProductDelete(productSeq);
		if(!result) {
			return "redirect:/product/read/" + productSeq;
		}
		return "redirect:/product/list";
	}
	
	
	
}
