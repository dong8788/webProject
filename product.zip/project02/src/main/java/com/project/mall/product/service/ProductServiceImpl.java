package com.project.mall.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.mall.product.domain.ProductVo;
import com.project.mall.product.persistence.ProductDao;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductDao productDao;

	@Override
	public List<ProductVo> productList() {
		// TODO Auto-generated method stub
		return productDao.list();
	}

	@Override
	public ProductVo ProductRead(int seq) {
		// TODO Auto-generated method stub
		return productDao.read(seq);
	}

	@Override
	public void ProductInsert(ProductVo dto) {
		productDao.insert(dto);
	}

	@Override
	public boolean ProductUpdate(ProductVo dto) {
		return productDao.update(dto);
	}

	@Override
	public boolean ProductDelete(int seq) {
		ProductVo dto = productDao.read(seq);
		return productDao.delete(dto);
	}
	


}
