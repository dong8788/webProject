package com.project.mall.product.domain;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class ProductVo {
	
	private int productSeq;  //제품seq
	private int sellerSeq;  //판매자seq
	
	private String category;  //카테고리
	private String prodName;  //제품명
	private String prodInfo;  //제품정보
	private int price;  //가격
	private int discount;  //할인가격
	private int shippingCharge;  //배송비
	private int stockNumber;  //재고
	private String photoUrl; //상품 이미지 경로
	private String thumbUrl;
	private MultipartFile photo; //사진
	private Date regDate;  //등록일
	private Date updateDate;  //수정일
	
	public int getProductSeq() {
		return productSeq;
	}
	public void setProductSeq(int productSeq) {
		this.productSeq = productSeq;
	}
	public int getSellerSeq() {
		return sellerSeq;
	}
	public void setSellerSeq(int sellerSeq) {
		this.sellerSeq = sellerSeq;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getProdInfo() {
		return prodInfo;
	}
	public void setProdInfo(String prodInfo) {
		this.prodInfo = prodInfo;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public int getShippingCharge() {
		return shippingCharge;
	}
	public void setShippingCharge(int shippingCharge) {
		this.shippingCharge = shippingCharge;
	}
	public int getStockNumber() {
		return stockNumber;
	}
	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}
	public String getPhotoUrl() {
		return photoUrl;
	}
	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}
	public String getThumbUrl() {
		return thumbUrl;
	}
	public void setThumbUrl(String thumbUrl) {
		this.thumbUrl = thumbUrl;
	}
	public MultipartFile getPhoto() {
		return photo;
	}
	public void setPhoto(MultipartFile photo) {
		this.photo = photo;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public ProductVo(int productSeq, int sellerSeq, String category, String prodName, String prodInfo, 
			int price, int discount, int shippingCharge, int stockNumber, String photoUrl, String thumbUrl, MultipartFile photo, Date regDate, Date updateDate) {

		this.productSeq = productSeq;
		this.sellerSeq = sellerSeq;
		this.category = category;
		this.prodName = prodName;
		this.prodInfo = prodInfo;
		this.price = price;
		this.discount = discount;
		this.shippingCharge = shippingCharge;
		this.stockNumber = stockNumber;
		this.photoUrl = photoUrl;
		this.thumbUrl = thumbUrl;
		this.photo = photo;
		this.regDate = regDate;
		this.updateDate = updateDate;
	}
	
	public ProductVo() {	}
	
	
	@Override
	public String toString() {
		return "ProductVo [productSeq=" + productSeq + ", sellerSeq=" + sellerSeq + ", category=" + category
				+ ", prodName=" + prodName + ", prodInfo=" + prodInfo + ", price=" + price + ", discount=" + discount
				+ ", shippingCharge=" + shippingCharge + ", stockNumber=" + stockNumber + ", photoUrl=" + photoUrl
				+ ", thumbUrl=" + thumbUrl + ", photo=" + photo + ", regDate=" + regDate + ", updateDate=" + updateDate
				+ "]";
	}
		

}
