package com.project.mall.product.persistence;

import java.util.List;

import com.project.mall.product.domain.ProductVo;

public interface ProductDao {
	
	public List<ProductVo> list();  //전체목록보기
	public ProductVo read(int req);  //하나보기
	public void insert(ProductVo dto);  //입력
	public boolean update(ProductVo dto);  //수정
	public boolean delete(ProductVo dto);  //삭제

}
